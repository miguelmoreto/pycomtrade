
Installing:

python setup.py install


Generating a distribution:

For a .tar.gz:
    python setup.py sdist

For a .zip:
    
    python setup.py sdist --format=zip